const ButtonSpinner = () => {
  return <span className="spinner" aria-hidden="true" />;
};

export default ButtonSpinner;
