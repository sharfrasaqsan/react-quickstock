import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useData } from "../contexts/DataContext";
import LoadingSpinner from "../utils/LoadingSpinner";

function Items() {
  const { items = [], loading, updateStock, updateItem } = useData();

  // page state
  const [query, setQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all"); // all | inStock | lowStock | outOfStock
  const [editingId, setEditingId] = useState(null);
  const [editingStock, setEditingStock] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  if (loading) return <LoadingSpinner />;

  // helpers
  const num = (n) => (Number(n) || 0).toLocaleString();
  const thrOf = (item) =>
    typeof item.lowStock === "number"
      ? item.lowStock
      : typeof item.minStock === "number"
      ? item.minStock
      : 0;

  const statusOf = (item) => {
    const stock = Number(item.stock) || 0;
    const thr = thrOf(item);
    if (stock === 0) return "outOfStock";
    if (thr > 0 && stock <= thr) return "lowStock";
    return "inStock";
  };

  const matchesQuery = (item) => {
    if (!query) return true;
    const q = query.toLowerCase();
    const name = String(item.name ?? "").toLowerCase();
    const id = String(item.id ?? item.sku ?? "").toLowerCase();
    return name.includes(q) || id.includes(q);
  };

  // filtering + counts (plain loops)
  const visible = [];
  let countAll = 0,
    countIn = 0,
    countLow = 0,
    countOut = 0;

  for (const it of items) {
    if (!matchesQuery(it)) continue;
    countAll += 1;
    const s = statusOf(it);
    if (s === "inStock") countIn += 1;
    if (s === "lowStock") countLow += 1;
    if (s === "outOfStock") countOut += 1;
    if (activeTab === "all" || activeTab === s) visible.push(it);
  }

  // inline editing
  const startEdit = (item) => {
    setEditingId(item.id);
    setEditingStock(String(Number(item.stock) || 0));
    setMessage("");
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditingStock("");
    setSaving(false);
    setMessage("");
  };

  const saveStock = async (item) => {
    const newStock = Math.max(0, Number(editingStock) || 0);
    setSaving(true);
    setMessage("");

    try {
      if (typeof updateStock === "function") {
        await updateStock(item.id, newStock);
      } else if (typeof updateItem === "function") {
        await updateItem(item.id, { stock: newStock });
      } else {
        // No redirect — just inform the user and stay on page
        setMessage(
          "Update function not found in DataContext. Please wire updateStock or updateItem."
        );
        setSaving(false);
        return;
      }
      setMessage("Stock updated.");
      cancelEdit(); // close editor on success
    } catch (err) {
      console.error(err);
      setMessage("Could not update stock. Please try again.");
      setSaving(false);
    }
  };

  // status badge
  const StatusBadge = ({ item }) => {
    const s = statusOf(item);
    if (s === "outOfStock")
      return <span className="badge text-bg-danger">Out</span>;
    if (s === "lowStock")
      return <span className="badge text-bg-warning">Low</span>;
    return <span className="badge text-bg-success">In</span>;
  };

  return (
    <div className="container my-3">
      {/* Page header */}
      <div className="d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-between gap-2 pb-3 mb-3 border-bottom">
        <div>
          <h1 className="h3 mb-1">Items</h1>
          <p className="text-muted mb-0">
            Search, filter, and update stock inline.
          </p>
        </div>
        <div className="d-flex gap-2">
          <Link to="/add-item" className="btn btn-primary">
            Add Item
          </Link>
          <Link to="/dashboard" className="btn btn-outline-secondary">
            Back to Dashboard
          </Link>
        </div>
      </div>

      {/* Search + tabs */}
      <div className="card mb-3">
        <div className="card-body">
          <div className="row g-2 align-items-center">
            <div className="col-12 col-md-6">
              <input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="form-control"
                placeholder="Search by name or ID…"
                aria-label="Search items"
              />
            </div>
            <div className="col-12 col-md-6 d-flex justify-content-md-end">
              <div
                className="btn-group gap-3"
                role="tablist"
                aria-label="Item filters"
              >
                <button
                  type="button"
                  className={`btn ${
                    activeTab === "all" ? "btn-primary" : "btn-outline-primary"
                  }`}
                  onClick={() => setActiveTab("all")}
                  aria-pressed={activeTab === "all"}
                >
                  All ({num(countAll)})
                </button>
                <button
                  type="button"
                  className={`btn ${
                    activeTab === "inStock"
                      ? "btn-success"
                      : "btn-outline-success"
                  }`}
                  onClick={() => setActiveTab("inStock")}
                  aria-pressed={activeTab === "inStock"}
                >
                  In ({num(countIn)})
                </button>
                <button
                  type="button"
                  className={`btn ${
                    activeTab === "lowStock"
                      ? "btn-warning"
                      : "btn-outline-warning"
                  }`}
                  onClick={() => setActiveTab("lowStock")}
                  aria-pressed={activeTab === "lowStock"}
                >
                  Low ({num(countLow)})
                </button>
                <button
                  type="button"
                  className={`btn ${
                    activeTab === "outOfStock"
                      ? "btn-danger"
                      : "btn-outline-danger"
                  }`}
                  onClick={() => setActiveTab("outOfStock")}
                  aria-pressed={activeTab === "outOfStock"}
                >
                  Out ({num(countOut)})
                </button>
              </div>
            </div>
          </div>

          {message && (
            <div className="alert alert-info mt-3 mb-0">{message}</div>
          )}
        </div>
      </div>

      {/* Items table */}
      <div className="card">
        <div className="card-body">
          {visible.length === 0 ? (
            <p className="text-muted mb-0">
              No items match your search/filter.
            </p>
          ) : (
            <div className="table-responsive">
              <table className="table align-middle">
                <thead>
                  <tr>
                    <th style={{ width: "40%" }}>Item</th>
                    <th style={{ width: 140 }}>Stock</th>
                    <th style={{ width: 140 }}>Min/Threshold</th>
                    <th style={{ width: 100 }}>Status</th>
                    <th style={{ width: 260 }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((item) => {
                    const isEditing = editingId === item.id;
                    const threshold = thrOf(item);
                    return (
                      <tr key={item.id}>
                        <td>
                          <div className="fw-medium">
                            {item.name || "Unnamed item"}
                          </div>
                        </td>

                        {/* Stock cell (plain input, no ± buttons) */}
                        <td>
                          {!isEditing ? (
                            <span className="fw-semibold">
                              {num(item.stock)}
                            </span>
                          ) : (
                            <input
                              type="number"
                              min={0}
                              className="form-control"
                              value={editingStock}
                              onChange={(e) => setEditingStock(e.target.value)}
                              disabled={saving}
                            />
                          )}
                        </td>

                        {/* Threshold */}
                        <td>
                          {threshold ? (
                            num(threshold)
                          ) : (
                            <span className="text-muted">—</span>
                          )}
                        </td>

                        {/* Status */}
                        <td>
                          <StatusBadge item={item} />
                        </td>

                        {/* Actions */}
                        <td>
                          {!isEditing ? (
                            <div className="d-flex flex-wrap gap-2">
                              <button
                                type="button"
                                className="btn btn-sm btn-outline-primary"
                                onClick={() => startEdit(item)}
                              >
                                Update stock
                              </button>
                              <Link
                                to={`/items/edit/${item.id}`}
                                className="btn btn-sm btn-outline-secondary"
                              >
                                Edit
                              </Link>
                            </div>
                          ) : (
                            <div className="d-flex flex-wrap gap-2">
                              <button
                                type="button"
                                className="btn btn-sm btn-success"
                                onClick={() => saveStock(item)}
                                disabled={saving}
                              >
                                {saving ? "Saving…" : "Save"}
                              </button>
                              <button
                                type="button"
                                className="btn btn-sm btn-outline-secondary"
                                onClick={cancelEdit}
                                disabled={saving}
                              >
                                Cancel
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Items;
